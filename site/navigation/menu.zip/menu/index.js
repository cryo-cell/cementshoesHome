function toggleMobileMenu(){
    menu = document.getElementById("mobileNavigation")
    menu.classList.toggle("open")
}